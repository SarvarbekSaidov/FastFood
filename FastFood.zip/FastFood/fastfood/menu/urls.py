from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('order/create/', views.create_order, name='create_order'),
    path('order/', views.order_list, name='order_list'),
    path('order/edit/<int:order_id>/', views.edit_order, name='edit_order'),
    path('order/delete/<int:order_id>/', views.delete_order, name='delete_order'),
    path('category/create/', views.create_category, name='create_category'),
    path('category/', views.category_list, name='category_list'),
    path('category/<int:category_id>/', views.products_by_category, name='products_by_category'),
]
