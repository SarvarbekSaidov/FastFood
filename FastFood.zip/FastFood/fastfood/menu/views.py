from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.models import User
from .models import Product, Order, Category
from .forms import OrderForm, CategoryForm

def home(request):
    categories = Category.objects.all()
    products = Product.objects.all()  # Show all products by default
    return render(request, 'home.html', {'categories': categories, 'products': products})

def create_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            admin_user = User.objects.get(username='admin')
            order.user = admin_user
            order.total_price = order.product.price * order.quantity
            order.save()
            return redirect('create_order')
    else:
        form = OrderForm()
    categories = Category.objects.all()
    return render(request, 'create_order.html', {'form': form, 'categories': categories})
def edit_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=order)
        if form.is_valid():
            form.save()
            return redirect('order_list')
    else:
        form = OrderForm(instance=order)
    return render(request, 'edit_order.html', {'form': form, 'order': order})

def delete_order(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if request.method == 'POST':
        order.delete()
        return redirect('order_list')
    return render(request, 'delete_order.html', {'order': order})

def order_list(request):
    orders = Order.objects.all()
    categories = Category.objects.all()
    return render(request, 'order_list.html', {'orders': orders, 'categories': categories})

def create_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('create_category')
    else:
        form = CategoryForm()
    categories = Category.objects.all()
    return render(request, 'create_category.html', {'form': form, 'categories': categories})

def category_list(request):
    categories = Category.objects.all()
    return render(request, 'category_list.html', {'categories': categories})

def products_by_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    products = Product.objects.filter(category=category)
    categories = Category.objects.all()
    return render(request, 'home.html', {'category': category, 'products': products, 'categories': categories})

