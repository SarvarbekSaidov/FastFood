from django import forms
from .models import Product, Order, Category

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = '__all__'

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

class OrderForm(forms.ModelForm):
    product_price = forms.DecimalField(max_digits=10, decimal_places=2, disabled=True, required=False, label="Price")

    class Meta:
        model = Order
        fields = ['name', 'product', 'quantity', 'product_price']

    def __init__(self, *args, **kwargs):
        super(OrderForm, self).__init__(*args, **kwargs)
        self.fields['product'].queryset = Product.objects.all()
        if 'product' in self.data:
            try:
                product_id = int(self.data.get('product'))
                self.fields['product_price'].initial = Product.objects.get(id=product_id).price
            except (ValueError, Product.DoesNotExist):
                pass
        elif self.instance.pk:
            self.fields['product_price'].initial = self.instance.product.price
